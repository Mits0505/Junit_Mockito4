package com.junit5;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MathUtilsTest {

	@Test
	void testSum() {
		MathUtils mathUtils = new MathUtils();
		int expected = 5;
		int actual = mathUtils.sum(3,2);
		assertEquals(expected, actual, "The add method should ass two numbers.");
	}
	
	@Test
	void testDivide() {
		MathUtils mathUtils = new MathUtils();
		assertThrows(ArithmeticException.class, ()->mathUtils.divide(1, 0),"Divide by 0 should throw an exception.");
	}
	
	@Test
	void testComputeCircleArea() {
		MathUtils mathUtils = new MathUtils();
		assertEquals(314.1592653589793, mathUtils.computeCircleArea(10),"Should return right circle area");
	}
}
